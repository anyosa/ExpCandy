SimulateSpdeField <- function(mesh, n.fields, range0, sigma0) {
  # mesh: an inla mesh
  # n.fields: how many separate fields
  # range0: number
  # sigma0: number
  
  # Compute values from known range and variance
  kappa0 <- sqrt(8) / range0
  tau0 <- 1 / (sqrt(4 * pi) * kappa0 * sigma0)
  
  # Define the spde object
  spde.stat <- inla.spde2.matern(mesh = mesh,
                                 B.tau = matrix(c(0, 1, 0), nrow = 1, ncol = 3),
                                 B.kappa=matrix(c(0, 0, 1), nrow = 1, ncol = 3))
  
  # Compute the precision matrix of the spde object
  Q.stat <- inla.spde2.precision(spde = spde.stat,
                                 theta = c(log(tau0), log(kappa0)))
  
  # Draw sample
  sample.field <- as.vector(inla.qsample(n = n.fields, Q = Q.stat))
  
  return(sample.field)
}



nRow = 4
nCol = 4
row    = rep(1:nRow, each  = nCol)
column = rep(1:nCol, times = nRow)
PYTPheno=data.frame(row    = c(row,    row),column = c(column, column))
PYTPheno$row    = c(row,    row)
PYTPheno$column = c(column, column)
PYTPheno$plot   = 1:nPlot
# Simulate plot (spatial) effects with variance varE * errorSpatial

# Construct a mesh
mesh.loc = expand.grid(x = c(1:nCol), y = (1:nRow))

mesh = inla.mesh.2d(loc = mesh.loc,  max.edge = c(1,3), offset = 1, cutoff = c(0.5,1))




sample.field = SimulateSpdeField(mesh, n.fields = 1, range0 = 2, sigma0 = 1)

# Plot the field
proj = inla.mesh.projector(mesh,dims=c(300, 300))
field.proj = inla.mesh.project(proj, sample.field[1:(length(sample.field))])


image.plot(list(x = proj$x, y=proj$y, z = field.proj),  ylim= c(0,nRow), xlim = c(0,nCol))


Z = matrix(c(1.5, 1,0.5, 0, 2,2,1,0.1,1,2,0.7,0.2,0.5,1.5,1.7,0.6), ncol = 4, byrow=T)
image.plot(Z,col =topo.colors(64))

mySeq = 1:16


#par(mar=c(5.1,4.1,4.1,2.1)
    
load("/Users/marialse/Box Sync/PlantFielsProject/PosterISBA2018/envir_discrete_cont.RData")

    
split.screen( rbind(c(0, .99,0,1), c(.99,1,0,1)))
# now divide up the figure region 
split.screen(c(2,1), screen=1)-> ind

zr<- range( -3,3)
# first image
screen( ind[1])
image.plot(list(x = proj$x, y=proj$y, z = field.proj),  ylim= c(0,nRow), xlim = c(0,nCol),col=tim.colors(), zlim=zr, xaxt = "n",yaxt = "n")

# second image
screen( ind[2])
image.plot(t(Z),col=tim.colors(), zlim=zr, xaxt = "n",yaxt = "n")

# move to skinny region on right and draw the legend strip 
screen( 2)
#image.plot( zlim=zr,legend.only=TRUE, smallplot=c(.1,.2, .3,.7),
       #     col=tim.colors())

close.screen( all=TRUE)




























