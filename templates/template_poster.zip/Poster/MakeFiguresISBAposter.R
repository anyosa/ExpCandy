# Make figures for ISBA poster 

Data <- read.table("/Users/marialse/Box\ Sync/PlantFielsProject/RealData/FileS1/pheno_data2011.txt", header=T)

ds <- data.frame(parc = Data$parc,row= Data$row,col= Data$col,trt = Data$trt, y = (Data$GY_SR_FI-mean(Data$GY_SR_FI, na.rm=T))/sqrt(var(Data$GY_SR_FI, na.rm = T)) , replic = Data$rep)

ds$row[ds$replic==2] = ds$row[ds$replic==1]  
# 
# 
# plotField = function(y,rows,cols){
#   z = matrix(NA_real_,nrow=max(rows),ncol=max(cols))
#   tmp = rows+(cols-1)*max(rows)
#   z[tmp] = y
#   image.plot(1:nrow(z),1:ncol(z),z=z, col = heat.colors(14),ylab="rows",xlab="cols")
# }
# 
# 
# 
# par(mfrow = c(2,1))
# plotField(ds$y[ds$replic==1], ds$col[ds$replic==1],ds$row[ds$replic==1])
# title("Observed grain yield 1")
# plotField(ds$y[ds$replic==2], ds$col[ds$replic==2],ds$row[ds$replic==2]-20)
# title("Observed grain yield 2")
# 
# 
# 

library(ggplot2)
library(fields)


# Observed data
ggplot(data = ds, aes(col, row)) + 
  geom_raster(aes(fill = y)) +
  scale_fill_gradient2(low=('red1'), mid='orange', high=('yellow'))+facet_wrap(~replic,ncol=1) +
  ggtitle("Observed grain yield") + xlab("Column") + ylab("Row") +
  theme(
    plot.title = element_text(color="black", size=22,face="bold"),
    axis.title.x = element_text(color="black", size=20),
    axis.title.y = element_text(color="black", size=20),
    text = element_text(size=20)
    
    
  )  

ggplot(data = ds[1:400,], aes(col, row)) + 
  geom_raster(aes(fill = y)) +
  scale_fill_gradient2(low=('red1'), mid='orange', high=('yellow')) +
  ggtitle("Observed grain yield") + xlab("Column") + ylab("Row") +
  theme(
    plot.title = element_text(color="black", size=22,face="bold"),
    axis.title.x = element_text(color="black", size=20),
    axis.title.y = element_text(color="black", size=20),
    text = element_text(size=20)
    
    
  )  




fullAverageCRPSgenetic_y_sep = fullAverageCRPSgenetic
fullAverageCRPS_y_sep = fullAverageCRPS
fullAverageCor_y_sep = fullAverageCor


par(mfrow = c(1,1))
par(mar=c(5.1,5.1,4.1,2.1))
    
    
plot( fullAverageCor_n_sep[,5] , type = 'o', col= 'red', ylim = c(0.35,0.92),lwd= 3, ylab = ("Average correlation"), xlab=("Spatial model"),xaxt = "n",cex.lab=1.5)
points(fullAverageCor_y_sep[,5],type = 'o',col = 'green',lwd = 3)
points(fullAverageCor_n_joint[,5], type = 'o', col = 'blue',lwd = 3)
points(fullAverageCor_y_joint[,5],type = 'o',col = 'orange',lwd = 3)
axis(1, at=1:5, labels=c("AR1xAR1", "ICAR","SPDE", "NoModel", "IID"),cex = 2)
legend(legend = c("Joint analysis","Joint analysis, genetic depdendency","Separate analysis" ,"Separate analysis, genetic depdendency" ), col = c("blue", "orange", "red","green"), x = "topright", lty = 1, lwd = 3, cex = 1.3)
title("Correlation breeding value")


# fullAverageCRPSgenetic_n_sep=fullAverageCRPSgenetic_n_sep[c(3,1,2,5,4),]
# fullAverageCRPSgenetic_y_sep=fullAverageCRPSgenetic_y_sep[c(3,1,2,5,4),]
# fullAverageCRPSgenetic_n_joint=fullAverageCRPSgenetic_n_joint[c(3,1,2,5,4),]
# fullAverageCRPSgenetic_y_joint=fullAverageCRPSgenetic_y_joint[c(3,1,2,5,4),]


plot( fullAverageCRPSgenetic_n_sep[,5] , type = 'o', col= 'red', ylim = c(0.85,1.6),lwd= 3, ylab = ("Average CRPS"), xlab=("Spatial model"),xaxt = "n",cex.lab=2,cex.axis=1.5)
points(fullAverageCRPSgenetic_y_sep[,5], type = 'o', col = 'green',lwd = 3)
points(fullAverageCRPSgenetic_n_joint[,5], type = 'o', col = 'blue',lwd = 3)
points(fullAverageCRPSgenetic_y_joint[,5],type = 'o',col = 'orange',lwd = 3)
axis(1, at=1:5, labels=c("SPDE", "AR1xAR1","ICAR", "IID", "NoModel"),cex.axis=1.5)
legend(legend = c("Joint analysis","Joint analysis, genetic depdendency","Separate analysis" ,"Separate analysis, genetic depdendency"), col = c("blue", "orange", "red","green"), x = "topright", lty = 1, lwd = 3, cex = 1.5)
title("True and estimated breeding value",cex.main=2)





plot( fullAverageCRPS_n_sep[,5] , type = 'o', col= 'red', ylim = c(1.2,6),lwd= 3, ylab = ("Average CRPS"), xlab=("Spatial model"),xaxt = "n",cex.lab=1.5)
points(fullAverageCRPS_y_sep[,5], type = 'o', col = 'green',lwd = 3)
points(fullAverageCRPS_n_joint[,5], type = 'o', col = 'blue',lwd = 3)
points(fullAverageCRPS_y_joint[,5],type = 'o',col = 'orange',lwd = 3)
axis(1, at=1:5, labels=c("AR1xAR1", "ICAR","SPDE", "NoModel", "IID"),cex = 2)
legend(legend = c("Joint analysis","Joint analysis, genetic depdendency","Separate analysis","Separate analysis, genetic depdendency" ), col = c("blue", "orange", "red","green"), x = "topright", lty = 1, lwd = 3, cex = 1.3)
title("CRPS linear predictor")

